<!-- Footer -->
<footer class="main">
	&copy; <?=date("Y")?> <strong>STEMS</strong>. 
    Design & Developed by 
	<a href="http://jazakallah.us" 
    	target="_blank">jazakallah.us</a>
</footer>
